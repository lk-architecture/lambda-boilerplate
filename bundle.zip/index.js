"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.handler = undefined;

require("babel-polyfill");

var _pipeline = require("./pipeline");

var _pipeline2 = _interopRequireDefault(_pipeline);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// pipeline definition is needed to avoid a babel-polyfill bug
var handler = exports.handler = _pipeline2.default;